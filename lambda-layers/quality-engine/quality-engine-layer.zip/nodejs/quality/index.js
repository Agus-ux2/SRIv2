module.exports = {
  ...require('./base.calculator'),
  ...require('./soja.calculator'),
  ...require('./trigo.calculator'),
  ...require('./maiz.calculator'),
  ...require('./sorgo.calculator'),
  ...require('./girasol.calculator'),
  ...require('./quality.service')
};
